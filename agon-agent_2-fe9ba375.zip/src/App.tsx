import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Pizza, MapPin, Phone, Star, Facebook, 
  Plus, X, ArrowLeft, ArrowRight, Truck, ShoppingBag 
} from 'lucide-react';
import './App.css';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  icon: React.ReactNode;
}

interface CartItem extends MenuItem {
  quantity: number;
}

interface GalleryImage {
  id: number;
  src: string;
  alt: string;
  caption: string;
}

const menuItems: MenuItem[] = [
  {
    id: 1,
    name: "Margherita Classica",
    description: "San Marzano tomatoes, fresh mozzarella di bufala, basil, extra virgin olive oil",
    price: 45,
    category: "Pizza",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 2,
    name: "Diavola Piccante",
    description: "Spicy salami, fiery chili flakes, mozzarella, tomato sauce",
    price: 55,
    category: "Pizza",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 3,
    name: "Quattro Formaggi",
    description: "Gorgonzola, fontina, parmesan, mozzarella on a creamy base",
    price: 58,
    category: "Pizza",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 4,
    name: "Prosciutto e Funghi",
    description: "Prosciutto crudo, wild mushrooms, arugula, truffle oil",
    price: 60,
    category: "Pizza",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 5,
    name: "Bruschetta Trio",
    description: "Classic tomato & basil, wild mushroom, roasted peppers",
    price: 42,
    category: "Antipasti",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 6,
    name: "Calamari Fritti",
    description: "Crispy fried squid with lemon aioli and marinara",
    price: 50,
    category: "Antipasti",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 7,
    name: "Tiramisù della Casa",
    description: "Traditional coffee-soaked ladyfingers with mascarpone and cocoa",
    price: 30,
    category: "Dessert",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 8,
    name: "Panna Cotta al Limone",
    description: "Silky lemon-infused panna cotta with berry compote",
    price: 32,
    category: "Dessert",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 9,
    name: "Aperol Spritz",
    description: "Aperol, prosecco, soda, orange slice – the taste of Rome",
    price: 40,
    category: "Drinks",
    icon: <Pizza className="w-8 h-8" />,
  },
  {
    id: 10,
    name: "Negroni Classico",
    description: "Gin, Campari, sweet vermouth – perfectly balanced",
    price: 45,
    category: "Drinks",
    icon: <Pizza className="w-8 h-8" />,
  },
];

const galleryImages: GalleryImage[] = [
  {
    id: 1,
    src: "/uploads/upload_1.png",
    alt: "Interior Loft View",
    caption: "Our cozy loft dining space overlooking Rome",
  },
  {
    id: 2,
    src: "/uploads/upload_2.jpg",
    alt: "Wood Fired Oven",
    caption: "Our authentic Neapolitan wood-fired oven",
  },
  {
    id: 3,
    src: "/uploads/upload_3.jpg",
    alt: "Signature Pizza",
    caption: "Freshly baked Margherita straight from the oven",
  },
  {
    id: 4,
    src: "/uploads/upload_4.jpg",
    alt: "Rooftop Terrace",
    caption: "Our beautiful rooftop terrace with city views",
  },
  {
    id: 5,
    src: "/pizza-hero.jpg",
    alt: "Pizza Closeup",
    caption: "Our famous wood-fired pies",
  },
  {
    id: 6,
    src: "/logo.png",
    alt: "Pizzeria Logo",
    caption: "Pizzeria Loft Roma",
  },
];

const testimonials = [
  {
    name: "Luca Rossi",
    role: "Local Food Critic",
    text: "The best pizza I've had in Rome. The crust is perfection and the loft atmosphere is unmatched.",
    rating: 5,
  },
  {
    name: "Sofia Moretti",
    role: "Travel Blogger",
    text: "A hidden gem in Trastevere. Incredible flavors and a truly unique loft experience.",
    rating: 5,
  },
  {
    name: "Marco Bianchi",
    role: "Chef & Owner of Trattoria Bella",
    text: "Their attention to ingredients and technique rivals any top pizzeria in Naples.",
    rating: 5,
  },
];

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  
  // Reservation form state
  const [reservationForm, setReservationForm] = useState({
    name: '',
    date: '',
    time: '',
    guests: '2',
    specialRequests: '',
  });

  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Pizza', 'Antipasti', 'Dessert', 'Drinks'];

  const filteredMenu = activeCategory === 'All' 
    ? menuItems 
    : menuItems.filter(item => item.category === activeCategory);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.findIndex(cartItem => cartItem.id === item.id);
      if (existing !== -1) {
        return prev.map((cartItem, index) =>
          index === existing 
            ? { ...cartItem, quantity: cartItem.quantity + 1 } 
            : cartItem
        );
      } else {
        return [...prev, { ...item, quantity: 1 }];
      }
    });
    
    showToast(`Added ${item.name} to cart`, 'success');
    
    // Brief cart peek animation
    setIsCartOpen(true);
    setTimeout(() => {
      setIsCartOpen(false);
    }, 1200);
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setCart(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 2800);
  };

  const handleReservationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!reservationForm.name || !reservationForm.date || !reservationForm.time) {
      showToast("Please fill in all required fields", 'error');
      return;
    }

    const message = encodeURIComponent(
      `*New Reservation from Loft Roma Website*\n\n` +
      `Name: ${reservationForm.name}\n` +
      `Date: ${reservationForm.date}\n` +
      `Time: ${reservationForm.time}\n` +
      `Guests: ${reservationForm.guests}\n` +
      `Special Requests: ${reservationForm.specialRequests || 'None'}\n\n` +
      `Please confirm availability!`
    );

    const whatsappUrl = `https://wa.me/21656557846?text=${message}`;
    window.open(whatsappUrl, '_blank');

    showToast("Opening WhatsApp with your reservation details...", 'success');
    setIsReservationOpen(false);
    
    // Reset form
    setReservationForm({
      name: '',
      date: '',
      time: '',
      guests: '2',
      specialRequests: '',
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setReservationForm(prev => ({ ...prev, [name]: value }));
  };

  const openImageModal = (index: number) => {
    setSelectedImageIndex(index);
    document.body.style.overflow = 'hidden';
  };

  const closeImageModal = () => {
    setSelectedImageIndex(null);
    document.body.style.overflow = 'visible';
  };

  const navigateImage = (direction: 'prev' | 'next') => {
    if (selectedImageIndex === null) return;
    
    let newIndex = selectedImageIndex + (direction === 'next' ? 1 : -1);
    if (newIndex < 0) newIndex = galleryImages.length - 1;
    if (newIndex >= galleryImages.length) newIndex = 0;
    
    setSelectedImageIndex(newIndex);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition - bodyRect - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    // Close mobile menu if open (we'll handle in JSX)
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white overflow-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-zinc-950/95 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                <Pizza className="w-6 h-6" />
              </div>
              <div>
                <div className="font-serif text-2xl tracking-tight">LOFT</div>
                <div className="text-[10px] text-red-500 -mt-1 tracking-[3px]">ROMA</div>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-10 text-sm uppercase tracking-widest">
            <button onClick={() => scrollToSection('home')} className="hover:text-red-500 transition-colors">Home</button>
            <button onClick={() => scrollToSection('menu')} className="hover:text-red-500 transition-colors">Menu</button>
            <button onClick={() => scrollToSection('gallery')} className="hover:text-red-500 transition-colors">Gallery</button>
            <button onClick={() => scrollToSection('about')} className="hover:text-red-500 transition-colors">Our Story</button>
            <button onClick={() => scrollToSection('visit')} className="hover:text-red-500 transition-colors">Visit Us</button>
          </div>

          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsCartOpen(!isCartOpen)}
              className="relative flex h-11 w-11 items-center justify-center rounded-full border border-white/20 hover:bg-white/5 transition-colors"
            >
              <Pizza className="w-5 h-5" />
              {cartCount > 0 && (
                <div className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-mono w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </div>
              )}
            </motion.button>

            <motion.button 
              onClick={() => setIsReservationOpen(true)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className="px-8 py-3 bg-red-600 hover:bg-red-700 rounded-full text-sm font-medium tracking-wider transition-all flex items-center gap-2"
            >
              RESERVE TABLE
            </motion.button>

            {/* Mobile Hamburger */}
            <button 
              onClick={() => {
                // For mobile we use a simple state but for simplicity we'll implement inlined
                const mobileMenu = document.getElementById('mobile-menu');
                if (mobileMenu) mobileMenu.classList.toggle('hidden');
              }}
              className="md:hidden p-3"
            >
              <div className="space-y-1.5">
                <div className="w-6 h-px bg-white"></div>
                <div className="w-6 h-px bg-white"></div>
                <div className="w-6 h-px bg-white"></div>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div id="mobile-menu" className="hidden md:hidden bg-zinc-950 border-t border-white/10 px-6 py-6">
          <div className="flex flex-col gap-4 text-sm uppercase tracking-widest">
            {['Home', 'Menu', 'Gallery', 'Our Story', 'Visit Us'].map((label, idx) => {
              const sectionId = label.toLowerCase() === 'our story' ? 'about' : 
                               label.toLowerCase() === 'visit us' ? 'visit' : label.toLowerCase();
              return (
                <button 
                  key={idx}
                  onClick={() => {
                    scrollToSection(sectionId);
                    const mobileMenu = document.getElementById('mobile-menu');
                    if (mobileMenu) mobileMenu.classList.add('hidden');
                  }}
                  className="py-3 text-left hover:text-red-500 transition-colors"
                >
                  {label}
                </button>
              );
            })}
            <button 
              onClick={() => {
                setIsReservationOpen(true);
                const mobileMenu = document.getElementById('mobile-menu');
                if (mobileMenu) mobileMenu.classList.add('hidden');
              }}
              className="mt-3 py-4 bg-red-600 text-center rounded-full"
            >
              MAKE A RESERVATION
            </button>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section id="home" className="relative h-screen flex items-center justify-center pt-20">
        <div className="absolute inset-0 bg-[radial-gradient(#3a3a3a_0.8px,transparent_1px)] bg-[length:4px_4px]"></div>
        
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="/pizza-hero.jpg" 
            alt="Pizzeria Hero" 
            className="absolute inset-0 w-full h-full object-cover opacity-75" 
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/90"></div>
        </div>

        <div className="relative z-10 text-center px-6 max-w-5xl">
          <motion.div 
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="inline-flex items-center gap-3 mb-6 px-6 py-1.5 bg-white/10 backdrop-blur rounded-full text-xs tracking-[4px] border border-white/20">
              TRASTEVERE • ROME
            </div>
            
            <h1 className="text-7xl md:text-[92px] font-serif tracking-[-4.2px] leading-none mb-6">
              PIZZERIA<br />LOFT ROMA
            </h1>
            
            <p className="max-w-md mx-auto text-xl md:text-2xl text-white/70 mb-12 font-light tracking-wide">
              Wood-fired tradition.<br />Modern loft spirit.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button 
                onClick={() => scrollToSection('menu')}
                whileHover={{ scale: 1.03 }}
                className="group px-14 py-5 border-2 border-white hover:bg-white hover:text-black text-sm tracking-[2px] transition-all flex items-center justify-center gap-3"
              >
                EXPLORE THE MENU
                <Pizza className="group-hover:rotate-12 transition" />
              </motion.button>
              
              <motion.button 
                onClick={() => setIsReservationOpen(true)}
                whileHover={{ scale: 1.03 }}
                className="px-14 py-5 bg-white text-black text-sm tracking-[2px] hover:bg-red-600 hover:text-white transition-all"
              >
                BOOK YOUR TABLE
              </motion.button>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-4">
              <motion.button 
                onClick={() => {
                  const msg = encodeURIComponent("Hello! I would like home delivery (livraison à domicile). Please send the menu and pricing.");
                  window.open(`https://wa.me/21656557846?text=${msg}`, '_blank');
                }}
                whileHover={{ scale: 1.03 }}
                className="px-8 py-4 border border-white/40 hover:bg-white/10 text-sm tracking-[2px] flex items-center gap-2 transition-all"
              >
                <Truck className="w-4 h-4" /> LIVRAISON À DOMICILE
              </motion.button>
              <motion.button 
                onClick={() => {
                  const msg = encodeURIComponent("Hello! I would like to order for takeout (à emporter). Please send the menu.");
                  window.open(`https://wa.me/21656557846?text=${msg}`, '_blank');
                }}
                whileHover={{ scale: 1.03 }}
                className="px-8 py-4 border border-white/40 hover:bg-white/10 text-sm tracking-[2px] flex items-center gap-2 transition-all"
              >
                <ShoppingBag className="w-4 h-4" /> À EMPORTER
              </motion.button>
            </div>
          </motion.div>
        </div>

        <motion.div 
          animate={{ y: [0, 12, 0] }}
          transition={{ duration: 2.4, repeat: Infinity }}
          className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center text-xs tracking-widest text-white/60"
        >
          SCROLL TO DISCOVER
          <div className="h-px w-5 bg-white/40 mt-2"></div>
        </motion.div>
      </section>

      {/* ABOUT / OUR STORY */}
      <section id="about" className="max-w-5xl mx-auto px-6 py-24 border-b border-white/10">
        <div className="grid md:grid-cols-12 gap-x-6">
          <div className="md:col-span-5 mb-12 md:mb-0">
            <div className="sticky top-24">
              <div className="uppercase tracking-[3px] text-red-500 text-sm mb-4">EST 2018</div>
              <h2 className="font-serif text-7xl leading-none tracking-tight mb-8">A loft.<br />A legacy.<br />A love for pizza.</h2>
              <div className="max-w-xs text-lg text-white/60">
                Overlooking the Mediterranean in beautiful Kélibia, our modern loft space brings authentic Italian pizza to the Tunisian coast.
              </div>
            </div>
          </div>
          
          <div className="md:col-span-7 space-y-8 text-lg text-white/80">
            <p>
              Founded by third-generation pizzaiolo Alessandro Moretti, Pizzeria Loft Roma marries the ancient craft of Neapolitan pizza with contemporary design. 
              Our 800-degree wood-fired oven — handcrafted in Naples — produces the signature leopard-spotted crust that has made us a local favorite.
            </p>
            <p>
              Every evening, the open loft dining room fills with the aroma of San Marzano tomatoes and fresh basil. The large windows look out onto the Mediterranean, offering spectacular sea views and golden sunsets.
            </p>
            
            <div className="pt-8 flex flex-wrap gap-8 border-t border-white/10">
              {[
                { number: "800°", label: "Wood-fired oven" },
                { number: "42", label: "Neapolitan recipes" },
                { number: "7", label: "Days a week" },
              ].map((stat, index) => (
                <div key={index} className="flex-1 min-w-[120px]">
                  <div className="text-6xl font-serif text-red-500 tracking-tighter mb-1">{stat.number}</div>
                  <div className="text-sm tracking-widest text-white/50">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* MENU SECTION */}
      <section id="menu" className="max-w-7xl mx-auto px-6 py-24">
        <div className="text-center mb-16">
          <div className="text-red-500 tracking-[4px] text-sm mb-3">FROM OUR KITCHEN</div>
          <h2 className="font-serif text-6xl tracking-tight mb-4">Signature Menu</h2>
          <p className="max-w-md mx-auto text-white/60">Handcrafted daily using the freshest local ingredients</p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-8 py-2.5 text-sm transition-all rounded-full border ${activeCategory === cat 
                ? 'bg-red-600 border-red-600 text-white' 
                : 'border-white/20 hover:border-white/40'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <AnimatePresence mode="wait">
            {filteredMenu.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 30 }}
                transition={{ delay: index * 0.03 }}
                className="pizza-card group bg-zinc-900 border border-white/10 rounded-3xl overflow-hidden flex flex-col"
              >
                <div className="h-72 bg-zinc-950 flex items-center justify-center relative overflow-hidden">
                  <div className="text-[180px] opacity-10 group-hover:scale-110 transition-transform duration-700">
                    {item.icon}
                  </div>
                  <div className="absolute bottom-6 right-6 bg-black/70 text-xs px-4 py-1 rounded-full tracking-widest flex items-center gap-1.5">
                    {item.category}
                  </div>
                </div>
                
                <div className="p-9 flex flex-col flex-1">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-serif text-3xl tracking-tight">{item.name}</h3>
                      <div className="text-red-500 font-mono mt-1">€{item.price}</div>
                    </div>
                  </div>
                  
                  <p className="text-white/70 flex-1 text-[15px] leading-relaxed mb-8">{item.description}</p>
                  
                  <button 
                    onClick={() => addToCart(item)}
                    className="mt-auto flex items-center justify-center gap-3 py-4 border border-white/30 hover:bg-white hover:text-zinc-950 transition-all rounded-xl text-sm tracking-widest group-hover:border-red-600"
                  >
                    ADD TO CART 
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="text-center mt-16 text-xs text-white/40 tracking-widest">
          All pizzas are made with Italian 00 flour • Vegetarian options available
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="bg-zinc-900 py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="uppercase text-xs tracking-[3px] text-red-500 mb-4">IN THE LOFT</div>
            <h2 className="font-serif text-6xl tracking-[-1.2px]">Moments captured</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {galleryImages.map((image, index) => (
              <motion.div 
                key={image.id}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="group relative overflow-hidden rounded-3xl aspect-[4/3] cursor-pointer"
                onClick={() => openImageModal(index)}
              >
                <img 
                  src={image.src} 
                  alt={image.alt} 
                  className="gallery-img absolute inset-0 w-full h-full object-cover" 
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/70 to-black/90 opacity-80 group-hover:opacity-100 transition-opacity" />
                
                <div className="absolute bottom-0 left-0 p-8 text-white z-10">
                  <div className="font-serif text-3xl tracking-tight mb-1">{image.caption.split(' – ')[0]}</div>
                  <div className="text-xs text-white/70 tracking-widest">{image.alt}</div>
                </div>
                
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                  <div className="text-xs border border-white/60 px-6 py-2.5 rounded-full tracking-widest">VIEW FULL RES</div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-10 text-xs text-white/50 tracking-widest">
            TAP ANY IMAGE TO ENLARGE
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="max-w-4xl mx-auto px-6 py-24">
        <div className="text-center mb-16">
          <Star className="inline-block mx-auto mb-6 text-red-500" />
          <h3 className="font-serif text-5xl tracking-tight">What Our Guests Say</h3>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ y: -6 }}
              className="bg-zinc-900 border border-white/10 p-10 rounded-3xl"
            >
              <div className="flex mb-8">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-red-500 text-red-500" />
                ))}
              </div>
              <p className="italic text-lg text-white/80 mb-10 leading-relaxed">“{testimonial.text}”</p>
              <div>
                <div className="font-medium">{testimonial.name}</div>
                <div className="text-xs text-red-500 tracking-widest mt-px">{testimonial.role}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* VISIT US / CONTACT */}
      <section id="visit" className="bg-black py-24 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-20">
          <div>
            <h2 className="font-serif text-6xl tracking-tight mb-8">Come find us</h2>
            
            <div className="space-y-8">
              <div className="flex gap-6">
                <div className="mt-1"><MapPin className="w-6 h-6 text-red-500" /></div>
                <div>
                  <div className="font-medium text-xl mb-1">R3VW+83Q, Rue de Tripoli</div>
                  <div className="text-white/70">Kélibia, Tunisia</div>
                  <a href="https://maps.google.com" target="_blank" className="inline-flex text-xs underline decoration-dotted hover:text-red-500 mt-3 transition">GET DIRECTIONS →</a>
                </div>
              </div>
              
              <div className="flex gap-6">
                <div className="mt-1"><Phone className="w-6 h-6 text-red-500" /></div>
                <div>
                  <div className="font-medium text-xl mb-1">+216 26 070 423</div>
                  <a href="https://wa.me/21656557846" target="_blank" className="text-white/70 hover:text-emerald-400 transition flex items-center gap-1">WhatsApp for Reservations</a>
                </div>
              </div>
              <div className="flex gap-6">
                <div className="mt-1"><Facebook className="w-6 h-6 text-red-500" /></div>
                <div>
                  <a href="https://www.facebook.com/share/1GYS4CErqB/" target="_blank" className="font-medium text-xl hover:text-blue-400 transition">Follow us on Facebook</a>
                  <div className="text-white/70 text-sm">Latest offers &amp; events</div>
                </div>
              </div>
            </div>
            
            <div className="mt-16">
              <div className="uppercase text-xs tracking-[3px] mb-4">OPENING HOURS</div>
              <div className="space-y-4 text-sm">
                {[
                  ["Tuesday — Sunday", "18:00 — 23:30"],
                  ["Kitchen closes at", "22:45"],
                  ["Closed Monday", ""],
                ].map(([day, hours], index) => (
                  <div key={index} className="flex justify-between border-b border-white/10 pb-4">
                    <div>{day}</div>
                    <div className="text-white/60 font-mono">{hours}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="relative h-[520px] md:h-auto bg-zinc-900 rounded-3xl overflow-hidden border border-white/10">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3256.5!2d11.088!3d36.853!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd4a5f5e5b5b5b%3A0x1234567890abcdef!2sK%C3%A9libia%2C%20Tunisia!5e0!3m2!1sen!2sfr!4v1729000000000!5m2!1sen!2sfr" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }}
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Pizzeria Loft Roma - Kélibia"
            ></iframe>
            
            <div className="absolute bottom-6 left-6 bg-zinc-950/95 backdrop-blur px-5 py-3 text-xs font-mono border border-white/20 rounded z-10">
              R3VW+83Q<br />Rue de Tripoli, Kélibia
            </div>
            
            <a 
              href="https://www.google.com/maps/search/?api=1&query=R3VW%2B83Q%2C+Rue+de+Tripoli%2C+K%C3%A9libia" 
              target="_blank"
              className="absolute bottom-6 right-6 bg-red-600 hover:bg-red-700 px-6 py-2.5 text-xs font-medium rounded-full flex items-center gap-2 transition-all z-10"
            >
              OPEN IN GOOGLE MAPS ↗
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-zinc-950 border-t border-white/10 py-20">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-12 gap-y-16">
          <div className="md:col-span-5">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-9 h-9 bg-red-600 rounded flex items-center justify-center">
                <Pizza className="w-5 h-5" />
              </div>
              <div className="font-serif text-4xl">LOFT ROMA</div>
            </div>
            
            <div className="max-w-xs text-sm text-white/60 leading-relaxed">
              Authentic wood-fired pizza in a beautiful rooftop loft overlooking the Mediterranean Sea.
            </div>
            
            <div className="mt-12 text-xs text-white/40">© {new Date().getFullYear()} Pizzeria Loft Roma. All rights reserved.</div>
          </div>

          <div className="md:col-span-2">
            <div className="uppercase text-xs tracking-widest mb-6">NAVIGATE</div>
            <div className="flex flex-col gap-y-4 text-sm">
              {['Menu', 'Gallery', 'Our Story', 'Visit'].map((l, i) => (
                <button key={i} onClick={() => scrollToSection(l.toLowerCase() === 'our story' ? 'about' : l.toLowerCase())} className="text-left hover:text-red-500 transition">
                  {l}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-5">
            <div className="uppercase text-xs tracking-widest mb-6">STAY IN TOUCH</div>
            <div className="text-sm max-w-xs">Join our mailing list for seasonal menus, special events and last-minute openings.</div>
            
            <form className="mt-7 flex">
              <input type="email" placeholder="YOUR EMAIL" className="flex-1 bg-transparent border-b border-white/30 pb-3 text-sm placeholder:text-white/40 focus:outline-none" />
              <button type="button" className="text-xs tracking-widest ml-8 hover:text-red-500 transition">JOIN</button>
            </form>
            
            <div className="mt-12 flex gap-8 text-xs">
              <a href="#" className="hover:text-red-500 transition">INSTAGRAM</a>
              <a href="#" className="hover:text-red-500 transition">RESERVATIONS</a>
            </div>
          </div>
        </div>
      </footer>

      {/* CART DRAWER */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-[60] flex justify-end" onClick={() => setIsCartOpen(false)}>
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 26, stiffness: 280 }}
              onClick={e => e.stopPropagation()}
              className="bg-zinc-950 border-l border-white/10 w-full max-w-md h-full flex flex-col"
            >
              <div className="p-8 flex justify-between items-center border-b border-white/10">
                <div>
                  <div className="font-serif text-3xl">YOUR CART</div>
                  <div className="text-xs tracking-widest text-white/40 mt-1">{cart.length} ITEMS</div>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="text-white/60 hover:text-white">
                  <X size={22} />
                </button>
              </div>

              {cart.length > 0 ? (
                <>
                  <div className="flex-1 overflow-auto px-8 py-6 space-y-7">
                    {cart.map((item, index) => (
                      <div key={index} className="flex gap-5">
                        <div className="flex-1">
                          <div className="font-medium tracking-tight">{item.name}</div>
                          <div className="text-xs text-white/50">€{item.price} × {item.quantity}</div>
                        </div>
                        
                        <div className="flex items-center gap-3 text-sm font-mono">
                          <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-7 h-7 flex items-center justify-center border border-white/20 hover:border-red-600 rounded">-</button>
                          <span>{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-7 h-7 flex items-center justify-center border border-white/20 hover:border-red-600 rounded">+</button>
                        </div>
                        
                        <div className="text-right w-16 font-medium text-lg tabular-nums">€{(item.price * item.quantity).toFixed(0)}</div>
                        
                        <button onClick={() => removeFromCart(item.id)} className="self-start text-white/30 hover:text-red-500 mt-1">
                          <X size={15} />
                        </button>
                      </div>
                    ))}
                  </div>
                  
                  <div className="p-8 border-t border-white/10 mt-auto">
                    <div className="flex justify-between text-lg mb-7">
                      <div>TOTAL</div>
                      <div className="font-medium tabular-nums">€{cartTotal}</div>
                    </div>
                    
                    <button 
                      onClick={() => {
                        setIsCartOpen(false);
                        setIsReservationOpen(true);
                        showToast("Thank you! We will confirm your order shortly.", 'success');
                        setCart([]);
                      }}
                      className="w-full py-5 bg-white text-black text-sm tracking-[1.5px] rounded-2xl font-medium active:scale-[0.985] transition"
                    >
                      COMPLETE ORDER
                    </button>
                    
                    <div className="text-center text-[10px] mt-4 text-white/40">or continue browsing</div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center px-10">
                  <div className="text-[110px] mb-6 opacity-10">🍕</div>
                  <div className="text-2xl mb-3">Your cart is empty</div>
                  <p className="text-white/60 max-w-[210px]">Time to add some delicious pizzas to your order!</p>
                  
                  <button 
                    onClick={() => setIsCartOpen(false)} 
                    className="mt-9 text-sm border border-white/30 px-8 py-3 rounded-full hover:bg-white/5"
                  >
                    BROWSE MENU
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* RESERVATION MODAL */}
      <AnimatePresence>
        {isReservationOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 p-4" onClick={() => setIsReservationOpen(false)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="bg-zinc-950 w-full max-w-lg rounded-3xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="px-9 pt-9 pb-8 border-b border-white/10 flex justify-between items-start">
                <div>
                  <div className="text-xs tracking-[3px] text-red-500">RESERVATIONS</div>
                  <div className="font-serif text-4xl mt-1 tracking-tight">Book a Table</div>
                </div>
                <button onClick={() => setIsReservationOpen(false)}><X className="text-white/60" /></button>
              </div>
              
              <form onSubmit={handleReservationSubmit} className="p-9 space-y-6">
                <div>
                  <label className="block uppercase text-xs tracking-widest mb-2 text-white/70">FULL NAME</label>
                  <input 
                    type="text" 
                    name="name"
                    value={reservationForm.name}
                    onChange={handleInputChange}
                    required 
                    className="w-full bg-transparent border-b border-white/30 pb-3 text-lg focus:outline-none placeholder:text-white/40" 
                    placeholder="Alessandro Bianchi" 
                  />
                </div>
                
                <div>
                  <label className="block uppercase text-xs tracking-widest mb-2 text-white/70">NUMBER OF GUESTS</label>
                  <select 
                    name="guests"
                    value={reservationForm.guests}
                    onChange={handleInputChange}
                    className="w-full bg-transparent border-b border-white/30 pb-3 text-white focus:outline-none"
                  >
                    {[1,2,3,4,5,6,7,8].map(n => (
                      <option key={n} value={n} className="bg-zinc-950">{n} guests</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block uppercase text-xs tracking-widest mb-2 text-white/70">DATE</label>
                    <input 
                      type="date" 
                      name="date"
                      value={reservationForm.date}
                      onChange={handleInputChange}
                      required 
                      className="w-full bg-transparent border-b border-white/30 pb-3 text-white focus:outline-none" 
                    />
                  </div>
                  <div>
                    <label className="block uppercase text-xs tracking-widest mb-2 text-white/70">TIME</label>
                    <select 
                      name="time"
                      value={reservationForm.time}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-transparent border-b border-white/30 pb-3 text-white focus:outline-none"
                    >
                      <option value="">Select time</option>
                      {Array.from({length: 11}, (_, i) => 18 + i).map(hour => (
                        <option key={hour} value={`${hour}:00`}>{hour}:00</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block uppercase text-xs tracking-widest mb-2 text-white/70">SPECIAL REQUESTS (OPTIONAL)</label>
                  <textarea 
                    name="specialRequests"
                    value={reservationForm.specialRequests}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full resize-y bg-transparent border border-white/30 rounded-2xl p-4 text-sm focus:outline-none placeholder:text-white/40" 
                    placeholder="Birthday cake, window seat, gluten-free..."
                  />
                </div>
                
                <button 
                  type="submit"
                  className="mt-4 w-full py-5 rounded-2xl bg-red-600 hover:bg-red-700 text-sm tracking-[2px] transition"
                >
                  CONFIRM RESERVATION
                </button>
                
                <div className="text-[10px] text-center text-white/40">We will confirm within the hour via email</div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* IMAGE LIGHTBOX */}
      <AnimatePresence>
        {selectedImageIndex !== null && (
          <div 
            className="fixed inset-0 z-[80] flex items-center justify-center bg-black/95 p-4"
            onClick={closeImageModal}
          >
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative max-w-5xl w-full"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative rounded-3xl overflow-hidden shadow-2xl modal">
                <img 
                  src={galleryImages[selectedImageIndex].src} 
                  alt={galleryImages[selectedImageIndex].alt} 
                  className="w-full max-h-[82vh] object-contain" 
                />
                
                <div className="absolute top-6 right-6 flex gap-3">
                  <button 
                    onClick={closeImageModal} 
                    className="bg-black/70 hover:bg-black text-white p-3 rounded-full"
                  >
                    <X size={22} />
                  </button>
                </div>
              </div>
              
              <div className="flex justify-between text-sm mt-6 text-white/60 px-4">
                <button 
                  onClick={() => navigateImage('prev')} 
                  className="flex items-center gap-3 hover:text-white transition"
                >
                  <ArrowLeft /> PREVIOUS
                </button>
                <div className="font-mono text-xs self-center">
                  {selectedImageIndex + 1} / {galleryImages.length}
                </div>
                <button 
                  onClick={() => navigateImage('next')} 
                  className="flex items-center gap-3 hover:text-white transition"
                >
                  NEXT <ArrowRight />
                </button>
              </div>
              
              <div className="text-center mt-6 text-sm tracking-widest text-white/70">
                {galleryImages[selectedImageIndex].caption}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TOAST NOTIFICATIONS */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 40, x: '-50%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className={`fixed bottom-8 left-1/2 z-[90] px-8 py-4 rounded-2xl flex items-center gap-3 shadow-2xl text-sm border ${toast.type === 'success' ? 'bg-emerald-900/90 border-emerald-500/40' : 'bg-red-900/90 border-red-500/40'}`}
          >
            {toast.type === 'success' ? '✓' : '⚠'} {toast.message}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
